 [![Monit](http://mmonit.com/monit/img/logo.png)](http://mmonit.com/monit) 


#Libmonit synthesis modules used by [Monit](http://mmonit.com/monit/) into a static library. Libmonit is built as part of Monit and is not meant to be installed nor distributed.

---
